#!/bin/bash
rsize=`/usr/bin/mongostat --port 28018 -n 1 | awk 'NR==2{print $11}' | cut -d '|' -f 1`
rnum=`/usr/bin/mongostat --port 28018 -n 1 | awk 'NR==2{print $11}' | cut -d '|' -f 1 | tr -d [A-Z]`
unit=${rsize:0-1:1}
if [ $unit = 'G' ]
then
         num=$( echo "$rnum*1000*1000*1000" | bc)
         echo $num
elif [ $unit = 'M' ]
then
         num=$( echo "$rnum*1000*1000" | bc)
         echo $num      
else
        echo "0"
fi

