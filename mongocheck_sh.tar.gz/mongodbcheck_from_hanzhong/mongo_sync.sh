#!/bin/bash
time_num=`mongo --port 28018 --eval "printjson(rs.printSlaveReplicationInfo())" | grep 'secs' | awk  '{print $1 }'`
if [ $time_num -lt 0 ]
then
  let time_num=0-$time_num
fi
echo $time_num

