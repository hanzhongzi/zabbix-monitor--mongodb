netout=`/usr/bin/mongostat --port 28018 -n 1 | awk 'NR==2{print $15}' | tr -cd "[0-9]"`
echo $netout
