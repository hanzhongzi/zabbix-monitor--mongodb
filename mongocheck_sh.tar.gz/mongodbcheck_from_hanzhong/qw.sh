#!/bin/bash
qw=`/usr/bin/mongostat --port 28018 -n 1 | awk 'NR==2{print $12}' | cut -d '|' -f 2`
echo $qw
