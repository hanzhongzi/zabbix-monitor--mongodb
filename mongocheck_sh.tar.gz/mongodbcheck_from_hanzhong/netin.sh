#!/bin/bash
netin=`/usr/bin/mongostat --port 28018 -n 1 | awk 'NR==2{print $14}' | tr -cd "[0-9]"`
echo $netin
