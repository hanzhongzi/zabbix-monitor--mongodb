#!/bin/bash
vsize=`/usr/bin/mongostat --port 28018 -n 1 | awk 'NR==2{print $10}' | cut -d '|' -f 1` 
vnum=`/usr/bin/mongostat --port 28018 -n 1 | awk 'NR==2{print $10}' | cut -d '|' -f 1 | tr -d [A-Z]`
unit=${vsize:0-1:1}
if [ $unit = 'G' ]
then
	 num=$( echo "$vnum*1000*1000*1000" | bc)
	 echo $num
elif [ $unit = 'M' ]
then
         num=$( echo "$vnum*1000*1000" | bc)
         echo $num	
else
	echo "0"
fi




