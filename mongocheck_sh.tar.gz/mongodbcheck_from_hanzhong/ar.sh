#!/bin/bash
ar=`/usr/bin/mongostat --port 28018 -n 1 | awk 'NR==2{print $13}' | cut -d '|' -f 1`
echo $ar
